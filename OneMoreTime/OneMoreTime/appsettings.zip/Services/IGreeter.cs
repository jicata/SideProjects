﻿namespace OneMoreTime.Services
{
    public interface IGreeter
    {
        string GetGreeting();
    }
}
