﻿namespace OneMoreTime.Controllers
{
    public class HomeController
    {
        public string Index()
        {
            return "Jello";
        }
    }
}
