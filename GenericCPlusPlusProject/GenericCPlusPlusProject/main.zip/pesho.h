//
// Created by Administrator on 3/27/2017.
//


class Pesho{

public:
    int wow();
};



