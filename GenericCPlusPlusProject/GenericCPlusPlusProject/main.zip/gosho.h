#pragma once
class Gosho {

public:
	bool bob(bool nadenica);
};
