//
// Created by Administrator on 3/27/2017.
//

#include "pesho.h"

int Pesho::wow(){
    return 5;
}
