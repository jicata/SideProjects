#include "gosho.h"


bool Gosho::bob(bool nadenica) {
	return nadenica;
}