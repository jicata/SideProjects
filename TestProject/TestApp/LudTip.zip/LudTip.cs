﻿namespace TestApp
{
    public class LudTip
    {
    }
}
