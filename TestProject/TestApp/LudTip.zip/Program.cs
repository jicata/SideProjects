﻿namespace TestApp
{
    using System;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ne");
        }
    }
}
