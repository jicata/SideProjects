﻿namespace EntityFrameworkCore
{
    using System.Collections.Generic;
    using MongoDB.Bson;
    using MongoDB.Driver;

    class Program
    {

        static void Main()
        {

           // const string ConnectionString = "mongodb://OJS:BEtcd6AkAye3VvEmj@localhost/OJS";
            const string ConnectionString = "mongodb://localhost";
            var client = new MongoClient(ConnectionString);
            IMongoDatabase db = client.GetDatabase("OJS");

            var collection = db.GetCollection<BsonDocument>("SubmissionsForProcessing");

            var doc = new BsonDocument {{"Item", "hehe"}};
            collection.InsertOne(doc);
            // InsertSubmissions(collection);

            //var filter = new FilterDefinitionBuilder<SubmissionForProcessing>().Where(s => s.Processed);
            //collection.Find(filter).ToList()
            //    .ForEach(s => Console.WriteLine(
            ////                 $"ID: {s.SubmissionId}; Processed: {s.Processed}; Processing: {s.Processing}"));
            //Expression<Func<SubmissionForProcessing, bool>> filterExpression = a => !a.Processed;
            //var update = Builders<SubmissionForProcessing>.Update.Set("SubmissionId", 6);

            //var updateResult = collection.UpdateMany(filterExpression, update);

            //Console.WriteLine(updateResult.ModifiedCount);
            //var stuff = db.GetCollection<SubmissionForProcessing>("SubmissionsForProcessing").AsQueryable();
            ////foreach (var submissionForProcessing in stuff)
            ////{
            ////    Console.WriteLine(
            ////        $"ID: {submissionForProcessing.SubmissionId}; " +
            ////        $"Processed: {submissionForProcessing.Processed}; " +
            ////        $"Processing: {submissionForProcessing.Processing}");
            ////}
            //Expression<Func<SubmissionForProcessing, bool>> xpression = a => !a.Processing;
            //collection.DeleteMany(xpression);
            //foreach (var submissionForProcessing in collection.AsQueryable())
            //{
            //    Console.WriteLine(
            //        $"ID: {submissionForProcessing.SubmissionId}; " +
            //        $"Processed: {submissionForProcessing.Processed}; " +
            //        $"Processing: {submissionForProcessing.Processing}");
            //}

        }

        private static void InsertSubmissions(IMongoCollection<SubmissionForProcessing> collection)
        {
            var submissionOne = new SubmissionForProcessing()
            {
                Processed = false,
                Processing = true,
                SubmissionId = 1
            };
            var submissionTwo = new SubmissionForProcessing()
            {
                Processed = false,
                Processing = false,
                SubmissionId = 2
            };
            var submissionThree = new SubmissionForProcessing()
            {
                Processed = true,
                Processing = false,
                SubmissionId = 3
            };

            var submissions = new List<SubmissionForProcessing>()
            {
                submissionOne,
                submissionTwo,
                submissionThree
            };

            collection.InsertMany(submissions);
        }
    }
}
