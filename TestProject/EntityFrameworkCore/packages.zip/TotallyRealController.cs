﻿namespace EntityFrameworkCore
{
    public class TotallyRealController
    {
        public void AddBlogToDb(string blogUrl)
        {
           // var dbContext = new BloggingContext();
        }
    }
}
