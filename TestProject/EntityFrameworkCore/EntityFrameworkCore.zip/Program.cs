﻿namespace EntityFrameworkCore
{
    using System;
    using System.Linq;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.DependencyInjection;

    class Program
    {
        private static IServiceProvider serviceProvider;
        static void Main()
        {
            string connectionString = @"Data Source=.;Initial Catalog=EFCore;Integrated Security=True";

            var options = new DbContextOptionsBuilder<BloggingContext>()
                .UseInMemoryDatabase(databaseName: "Whatever man")
                .Options;

            var standardOptions = new DbContextOptionsBuilder<BloggingContext>()
                .UseSqlServer(@"Data Source=.;Initial Catalog=EFCore;Integrated Security=True")
                .Options;

            var services = new ServiceCollection()
                .AddDbContext<BloggingContext>(b => b.UseInMemoryDatabase());

            serviceProvider = services.BuildServiceProvider();

            var serviced = serviceProvider.GetService<BloggingContext>();
            serviced.Blogs.Add(new Blog() {Rating = 5});
            serviced.SaveChanges();

            //var db = new BloggingContext(options);


            //var blog = new Blog { Url = "http://sample.com" };
            //db.Add(blog);
            //db.SaveChanges();
            //var retrieved = db.Blogs.FirstOrDefault();
            //Console.WriteLine(retrieved.Url);




        }
    }
}
