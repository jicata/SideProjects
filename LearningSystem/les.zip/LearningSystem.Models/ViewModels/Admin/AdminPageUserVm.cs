﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningSystem.Models.ViewModels.Admin
{
    public class AdminPageUserVm
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
