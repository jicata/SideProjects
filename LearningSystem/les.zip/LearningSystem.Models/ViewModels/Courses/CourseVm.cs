﻿namespace LearningSystem.Models.ViewModels.Courses
{
    public class CourseVm
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
