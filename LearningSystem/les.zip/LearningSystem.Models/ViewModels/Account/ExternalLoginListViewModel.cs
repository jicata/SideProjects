﻿namespace LearningSystem.Models.ViewModels.Account
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}
