using LearningSystem.Models.EntityModels;

namespace LearningSystem.Services.Interfaces
{
    public interface IAccountService
    {
        void CreateStudent(ApplicationUser user);
    }
}