﻿namespace Models
{
    public class TestModel
    {
        public int Id { get; set; }
        
    }
}
