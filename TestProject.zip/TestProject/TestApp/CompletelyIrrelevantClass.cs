﻿namespace TestApp
{
    using System;

    public class CompletelyIrrelevantClass : SomewhatIrrelevantClass
    {
        public void IrrelevantMethod()
        {
            Console.WriteLine("I'm irrelevant");
        }
    }
}
