﻿namespace TestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            CompletelyIrrelevantClass irrelevant = new CompletelyIrrelevantClass();
            irrelevant.IrrelevantMethod();
        }
    }
}
