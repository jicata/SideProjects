﻿namespace TestApp
{
    using System;

    public class SomewhatIrrelevantClass
    {
        public int Id { get; set; }
        
        public virtual void Relevancy()
        {
            Console.WriteLine("It's a lie");
        }
    }
}
