﻿namespace DotNetCoreConsoleApp
{
    public class Hehe
    {
        public string LaughItOff()
        {
            return "Hehe";
        }
    }
}
