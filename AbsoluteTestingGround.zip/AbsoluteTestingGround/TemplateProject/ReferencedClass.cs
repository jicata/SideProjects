﻿namespace TemplateProject
{
    public class ReferencedClass
    {
        public int Id { get; set; }
        
    }
}
