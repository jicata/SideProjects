package com.photographyworkshops.service;

import com.photographyworkshops.domain.dto.accessoaries.AccessoryImportXMLDto;

public interface AccessoryService {

    void create(AccessoryImportXMLDto accessoryDto);
}
