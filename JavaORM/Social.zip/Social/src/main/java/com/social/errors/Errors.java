package com.social.errors;

public class Errors {
    public static final String INVALID_CREDENTIALS = "Invalid Credentials";
}
