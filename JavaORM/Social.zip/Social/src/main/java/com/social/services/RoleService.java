package com.social.services;


import com.social.entities.Role;

public interface RoleService {

    Role getDefaultRole();
}
