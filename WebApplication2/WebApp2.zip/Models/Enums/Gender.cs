﻿namespace WebApplication2.Models.Enums
{
    public enum Gender
    {
        Female,
        Male
    }
}